import { gateway } from "@ai-sdk/gateway";
import { LanguageModelV2 } from "@ai-sdk/provider";
import {
  customProvider,
  extractReasoningMiddleware,
  wrapLanguageModel,
} from "ai";
import { isTestEnvironment } from "../constants";

const customModel: LanguageModelV2 = {
  specificationVersion: "v2",
  provider: "custom",
  modelId: "custom-model",
  supportedUrls: [],
  async doGenerate(options) {
    const response = await fetch("/api/custom-model", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: options.prompt[0] }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(`Custom model API error: ${error.error}`);
    }

    const json = await response.json();

    return {
      content: [{ type: "text", text: json.content }],
      finishReason: "stop",
      usage: {
        inputTokens: 0,
        outputTokens: 0,
        totalTokens: 0,
      },
      warnings: [],
    };
  },
  async doStream(options) {
    throw new Error("Streaming not supported");
  }
};

export const myProvider = isTestEnvironment
  ? (() => {
      const {
        artifactModel,
        chatModel,
        reasoningModel,
        titleModel,
      } = require("./models.mock");
      return customProvider({
        languageModels: {
          "chat-model": chatModel,
          "chat-model-reasoning": reasoningModel,
          "title-model": titleModel,
          "artifact-model": artifactModel,
        },
      });
    })()
  : customProvider({
      languageModels: {
        "chat-model": gateway.languageModel("xai/grok-2-vision-1212"),
        "chat-model-reasoning": wrapLanguageModel({
          model: gateway.languageModel("xai/grok-3-mini"),
          middleware: extractReasoningMiddleware({ tagName: "think" }),
        }),
        "title-model": gateway.languageModel("xai/grok-2-1212"),
        "artifact-model": gateway.languageModel("xai/grok-2-1212"),
        "custom-model": customModel,
      },
    });
