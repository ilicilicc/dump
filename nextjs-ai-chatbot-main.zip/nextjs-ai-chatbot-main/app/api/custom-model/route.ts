import { StreamingTextResponse } from 'ai/rsc'

export const runtime = 'edge'

export async function POST(req: Request) {
  const { messages } = await req.json()

  try {
    const response = await fetch(`${process.env.CUSTOM_MODEL_API_URL}/api/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ messages }),
    })

    if (!response.ok) {
      throw new Error(`API error: ${response.statusText}`)
    }

    const stream = new ReadableStream({
      async start(controller) {
        const reader = response.body?.getReader()
        const decoder = new TextDecoder()

        if (!reader) {
          controller.close()
          return
        }

        try {
          while (true) {
            const { done, value } = await reader.read()
            
            if (done) break
            
            const chunk = decoder.decode(value, { stream: true })
            const lines = chunk.split('\n')
            
            for (const line of lines) {
              if (line.startsWith('data: ')) {
                const data = line.slice(6)
                
                if (data === '[DONE]') continue
                
                try {
                  const parsed = JSON.parse(data)
                  if (parsed.token) {
                    controller.enqueue(new TextEncoder().encode(parsed.token))
                  } else if (parsed.error) {
                    console.error('Model Error:', parsed.error)
                  }
                } catch (e) {
                  // Skip malformed JSON
                }
              }
            }
          }
        } finally {
          controller.close()
        }
      },
    })

    return new StreamingTextResponse(stream)
  } catch (error) {
    console.error("Error in custom model API:", error);
    return new Response("Internal Server Error", { status: 500 });
  }
}
