from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
import torch
import json
from typing import List
from dump.hst_v7_1_ultimate import HSTv7_1Ultimate
from transformers import GPT2Tokenizer

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize model
model = HSTv7_1Ultimate(
    vocab_size=50257,
    d_model=128,
    n_heads=4,
    n_layers=2,
    horizon=16,
    mode='token',
    chunk_size=128
)
model.eval()

tokenizer = GPT2Tokenizer.from_pretrained('gpt2')

class Message(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    messages: List[Message]

async def generate_tokens(prompt: str):
    input_ids = tokenizer.encode(prompt, return_tensors='pt')
    
    with torch.no_grad():
        current_ids = input_ids
        cache = None
        
        for _ in range(50): # max tokens to generate
            # Forward pass
            outputs = model(current_ids, cache=cache)
            cache = outputs['cache']
            
            # Get next token
            next_token_logits = outputs['logits'][:, -1, :]
            next_token = torch.argmax(next_token_logits, dim=-1).unsqueeze(0)
            
            # Decode and stream the token
            token_text = tokenizer.decode(next_token[0])
            
            # Send as Server-Sent Event
            yield f"data: {json.dumps({'token': token_text})}\n\n"
            
            # Update current_ids for next iteration
            current_ids = next_token
            
            # Stop if EOS token
            if next_token.item() == tokenizer.eos_token_id:
                break
    
    yield "data: [DONE]\n\n"

# To run this server, use the following command:
# uvicorn server:app --host 0.0.0.0 --port 8000

@app.post("/api/chat")
async def chat(request: ChatRequest):
    last_message = request.messages[-1].content if request.messages else ""
    
    return StreamingResponse(
        generate_tokens(last_message),
        media_type="text/event-stream"
    )

@app.get("/")
async def health():
    return {"status": "ok"}
